const Joi = require('joi');
const { dniScalar } = require('../joi.primitives');

const personalSchema = Joi.object({
    displayName: Joi.string().max(250).required()
        .messages({ 'any.required': 'El nombre es requerido.' }),
    photoURL: Joi.string().uri()
        .default('https://cdn.pixabay.com/photo/2016/12/02/16/35/picture-frame-1878069_640.jpg'),
    address: Joi.string().max(250).required()
        .messages({ 'any.required': 'La dirección es requerida.' }),
    city: Joi.string().max(120).required()
        .messages({ 'any.required': 'La ciudad es requerida.' }),
    province: Joi.string().max(120).required()
        .messages({ 'any.required': 'La provincia es requerida.' }),
    ratingAvg: Joi.number().min(0).max(10).precision(2)
        .messages({ 'number.base': 'ratingAvg debe ser numérico.' }),
    ratingCount: Joi.number().integer().min(0)
        .messages({ 'number.base': 'ratingCount debe ser numérico entero.' }),
}).required();

const premiumSchema = Joi.object({
    plan: Joi.string().valid('standard', 'plus').required()
        .messages({ 'any.only': 'plan debe ser "standard" o "plus".' }),
    since: Joi.number().integer().min(0).allow(null).optional()
        .messages({ 'number.base': 'since debe ser un entero (timestamp ms).' }),
}).required();

const servicesSchema = Joi.object().pattern(
    Joi.string().min(1),
    Joi.object().pattern(Joi.string().min(1), Joi.valid(true))
);

const dniUserSchema = Joi.object({
    dni: dniScalar
});

const userPayloadSchema = Joi.object({
    role: Joi.string().valid('admin', 'client', 'pro').required()
        .messages({ 'any.only': 'role debe ser "admin", "client" o "pro".' }),
    email: Joi.string().lowercase().email().max(254).required(),
    is_deleted: Joi.boolean().optional().default(false),
    personal: personalSchema,
    premium: premiumSchema,
    services: servicesSchema.optional(),
    ratingAvg: Joi.number().min(0).max(10).precision(2),
    ratingCount: Joi.number().integer().min(0),
});

const initialPatchSchema = Joi.object({
    displayName: Joi.string().max(250),
    dni: dniScalar,
    photoURL: Joi.string().uri(),
    address: Joi.string().max(250),
    city: Joi.string().max(120),
    province: Joi.string().max(120)
}).min(1);

const personalPatchSchema = Joi.object({
    displayName: Joi.string().max(250),
    photoURL: Joi.string().uri(),
    address: Joi.string().max(250),
    city: Joi.string().max(120),
    province: Joi.string().max(120),
}).min(1);

const rolePatchSchema = Joi.object({
    role: Joi.string().valid('admin', 'client', 'pro').required()
        .messages({ 'any.only': 'role debe ser "admin", "client" o "pro".' })
});

const listUsersQuerySchema = Joi.object({
    role: Joi.string().valid('admin', 'client', 'pro').optional(),
    city: Joi.string().max(120).optional(),
    province: Joi.string().max(120).optional(),
    active: Joi.boolean().truthy('true', 'false').optional(),
});

const statusPatchSchema = Joi.object({
    is_deleted: Joi.boolean().required()
        .messages({ 'any.required': 'is_deleted es requerido.' })
});

module.exports = { 
    dniUserSchema,
    premiumSchema,
    userPayloadSchema, 
    initialPatchSchema,
    personalPatchSchema,
    rolePatchSchema,
    listUsersQuerySchema,
    statusPatchSchema,
};